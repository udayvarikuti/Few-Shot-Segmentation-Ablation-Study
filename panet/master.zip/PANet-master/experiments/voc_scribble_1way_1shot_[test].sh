# VOC 1-way 1-shot
python test.py with gpu_id=3 mode='test' scribble=True snapshot='./runs/PANet_VOC_align_sets_0_1way_1shot_[train]/1/snapshots/30000.pth'
python test.py with gpu_id=3 mode='test' scribble=True snapshot='./runs/PANet_VOC_align_sets_1_1way_1shot_[train]/1/snapshots/30000.pth'
python test.py with gpu_id=3 mode='test' scribble=True snapshot='./runs/PANet_VOC_align_sets_2_1way_1shot_[train]/1/snapshots/30000.pth'
python test.py with gpu_id=3 mode='test' scribble=True snapshot='./runs/PANet_VOC_align_sets_3_1way_1shot_[train]/1/snapshots/30000.pth'